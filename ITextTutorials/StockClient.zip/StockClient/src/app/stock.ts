export class Stock {
    constructor(
        public stackId:number,
        public name:string, 
        public cost:number,
        public isUpdate:boolean 
        ){}
}
